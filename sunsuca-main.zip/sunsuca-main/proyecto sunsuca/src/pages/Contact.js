// src/pages/Contact.js
import React from 'react';

const Contact = () => {
  return (
    <div>
      <h1>Contáctanos</h1>
      <p>Por favor, envíanos un mensaje y nos pondremos en contacto contigo.</p>
    </div>
  );
};

export default Contact;
